To run this code, you need to have Python 3 installed. Open a terminal in the folder that contains the code.py file and run:

```sh
python code.py
```

This will generate the `group_51.txt` with the answers to the questions. The answers are rounded to 3 decimal places.